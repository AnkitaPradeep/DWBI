USE [AdventureWorks2014]
GO

DROP TABLE IF EXISTS [HumanResources].[EmpStagingTable];
CREATE TABLE [HumanResources].[EmpStagingTable](
	[BusinessEntityID] [varchar] (100) NOT NULL,
	[NationalIDNumber] [varchar] (100) NOT NULL,
	[LoginID] [varchar] (100) NOT NULL,
	[OrganizationNode] [varchar] (100) NULL,
	[OrganizationLevel]  [varchar] (100),
	[JobTitle] [varchar] (100) NOT NULL,
	[BirthDate] [varchar] (100) NOT NULL,
	[MaritalStatus] [varchar] (100) NOT NULL,
	[Gender] [varchar] (100) NOT NULL,
	[HireDate] [varchar] (100) NOT NULL,
	[SalariedFlag] [varchar] (100) NOT NULL,
	[VacationHours] [varchar] (100) NOT NULL,
	[SickLeaveHours] [varchar] (100) NOT NULL,
	[CurrentFlag] [varchar] (100) NOT NULL,
	[rowguid] [varchar] (100)   NOT NULL,
	[ModifiedDate] [varchar] (100) NOT NULL,
	PRIMARY KEY ([BusinessEntityID])) ;

	select * from HumanResources.EmpStagingTable;

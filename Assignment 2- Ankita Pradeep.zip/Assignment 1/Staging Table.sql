USE [AdventureWorks2014]
GO

DROP TABLE IF EXISTS [HumanResources].[SSISTestEmployee];
CREATE TABLE [HumanResources].[SSISTestEmployee](
	[BusinessEntityID] [int] NOT NULL,
	[NationalIDNumber] [nvarchar](15) NOT NULL,
	[LoginID] [nvarchar](256) NOT NULL,
	[OrganizationNode] [hierarchyid] NULL,
	[OrganizationLevel]  AS ([OrganizationNode].[GetLevel]()),
	[JobTitle] [nvarchar](50) NOT NULL,
	[BirthDate] [date] NOT NULL,
	[MaritalStatus] [nchar](1) NOT NULL,
	[Gender] [nchar](1) NOT NULL,
	[HireDate] [date] NOT NULL,
	[SalariedFlag] [dbo].[Flag] NOT NULL,
	[VacationHours] [smallint] NOT NULL,
	[SickLeaveHours] [smallint] NOT NULL,
	[CurrentFlag] [dbo].[Flag] NOT NULL,
	[rowguid] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
	PRIMARY KEY ([BusinessEntityID])) ;


ALTER TABLE [HumanResources].[SSISTestEmployee] 
ADD CONSTRAINT [DF_SalariedFlag] 
DEFAULT ((1)) FOR [SalariedFlag] 

ALTER TABLE [HumanResources].[SSISTestEmployee]
ADD  CONSTRAINT [DF_SickLeaveHours]
DEFAULT ((0)) FOR [SickLeaveHours]

ALTER TABLE [HumanResources].[SSISTestEmployee] 
ADD  CONSTRAINT [DF_VacationHours]  
DEFAULT ((0)) FOR [VacationHours]

ALTER TABLE [HumanResources].[SSISTestEmployee] 
ADD  CONSTRAINT [DF_CurrentFlag] 
DEFAULT ((1)) FOR [CurrentFlag]

ALTER TABLE [HumanResources].[SSISTestEmployee]  
WITH CHECK ADD  CONSTRAINT [CK_SSIS_BirthDate] 
CHECK  (([BirthDate]>='1930-01-01' AND [BirthDate]<=dateadd(year,(-18),getdate())))

ALTER TABLE [HumanResources].[SSISTestEmployee]
CHECK CONSTRAINT [CK_SSIS_BirthDate]

ALTER TABLE [HumanResources].[SSISTestEmployee] 
WITH CHECK ADD  CONSTRAINT [CK_Gender] 
CHECK  ((upper([Gender])='F' OR upper([Gender])='M'))

ALTER TABLE [HumanResources].[SSISTestEmployee] 
CHECK CONSTRAINT [CK_Gender]

